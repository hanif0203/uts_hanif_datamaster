<?php $__env->startSection('content'); ?>
<div class="header1">
    <div class="container mt-4">
        <div id="carouselExampleFade" class="carousel slide" data-bs-ride="carousel" style="width: 80%">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src=" <?php echo e(Vite::asset('resources/images/foto1jpg.jpg')); ?>"alt="" width="80%">
              </div>
              <div class="carousel-item">
                <img src=" <?php echo e(Vite::asset('resources/images/gambar2.png')); ?>"alt="" width="80%">
              </div>
              <div class="carousel-item">
                <img src=" <?php echo e(Vite::asset('resources/images/gambar4.jpeg')); ?>"alt="" width="80%">
              </div>
              <div class="carousel-item">
                <img src=" <?php echo e(Vite::asset('resources/images/gambar 1.jpg')); ?>"alt="" width="80%">
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next" style="width: 56%">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
        </div>
        <br><br>
    </div>
    <div class="deskripsi 1">
      <div class="p-5 bg-light rounded-3 col-xl-4 border">
        <h2>Let's Buy Now!</h2>
        <h5>UD SUBUR JAYA berada di jalan kecipik .
          Berdiri sejak tahun 2010.
          Menjual berbagai macam bahan bangunan . Pasir,cat,batu bata,dll.
          
        </h5>
        <p>    Dengan harga yang sangat terjangkau dan di jamin kualitas bahan bangunannya sangat bagus.
          Buka setiap hari.
          Kami mampu bersaing dengan bisnis bisnis yang ada di jalan kecipik dan di sekitarnya.
          Get discounts and promos with applicable conditions</p>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app.scss'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/welcome.scss'); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HANIF\OneDrive\Documents\ppepepepe\Uts_framwok_hanifbahyhasyid_1204210143\resources\views/home.blade.php ENDPATH**/ ?>