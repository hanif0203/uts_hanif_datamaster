<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PersediaanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('Persediaans')->insert([
            [
                'KodeBarang' => '01',
                'NamaBarang' => 'Mie',
                'hargaBarang' => 10000,
                'deskripsiBarang' => 'enak dan siap santap',
                'Satuan_id' => 1
            ],
            [
                'KodeBarang' => '02',
                'NamaBarang' => 'milk shake',
                'HargaBarang' => 5000,
                'DeskripsiBarang' => 'enak dan menyegarkan',
                'Satuan_id' => 2
            ],
            [
                'kode_barang' => '03',
                'nama_barang' => 'Gorengan',
                'harga_barang' => 4000,
                'deskripsi_barang' => 'enak dan bikin kenyang',
                'satuan_id' => 3
            ]
        ]);
    }
}