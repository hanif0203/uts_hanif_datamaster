<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;


class SatuanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('satuans')->insert([
            [
                'codesatuan' => '1-100b',
                'namasatuan' => '1-100 Biji',
            ],
            [
                'codesatuan' => '1 KD',
                'namasatuan' => '1 Kardus',
            ],
            [
                'codesatuan' => '2 KD',
                'namasatuan' => '2 Kardus',
            ],
            [
                'codesatuan' => '3 KD',
                'namasatuan' => '3 Kardus',
            ],
            [
                'codesatuan' => 'Trk',
                'namasatuan' => ' 1 TRUK',
            ],
            [
                'codesatuan' => '100 -1000 b',
                'namasatuan' => '100-1000 Biji',
            ],
        ]);

    }
}
