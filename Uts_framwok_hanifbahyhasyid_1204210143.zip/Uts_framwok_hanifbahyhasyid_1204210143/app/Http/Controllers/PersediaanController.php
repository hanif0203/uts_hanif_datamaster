<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\persediaan;
use App\Models\Satuan;
use Illuminate\Validation\Rule;


class PersediaanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pageTitle = 'Daftar Persediaan';
           
        // ELOQUENT
            $persediaans = persediaan::all();
            return view('persediaan.index', [
                'pageTitle' => $pageTitle,
                'persediaans' => $persediaans
            ]);
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $pageTitle = 'Create Persediaan';

        //ELOQUENT
        $satuans = Satuan::all();
        return view('persediaan.create', compact('pageTitle', 'satuans'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $messages = [
            'required' => ':Attribute harus diisi.',
            'numeric' => 'Isi :attribute dengan angka',
            'KodeBarang.unique' => 'kode barang sudah ada',
        ];

        $validator = Validator::make($request->all(), [
            'KodeBarang' => 'required|unique:persediaans,KodeBarang',
            'NamaBarang' => 'required',
            'HargaBarang' => 'required|numeric',
            'DeskripsiBarang' => 'required',
        ], $messages);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();


        }

        //ELOQUENT
        $persediaan = New persediaan;
        $persediaan ->KodeBarang = $request->KodeBarang;
        $persediaan ->NamaBarang = $request->NamaBarang;
        $persediaan ->HargaBarang = $request->HargaBarang;
        $persediaan ->DeskripsiBarang = $request->DeskripsiBarang;
        $persediaan ->satuan_id = $request->satuan;
        $persediaan ->save();

        return redirect()->route('persediaan.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $pageTitle = 'Detail Persediaan';

        //QueryBuilder
        // $barang = DB::table('barangs')->select('barangs.*', 'satuans.nama_satuan as satuan_nama_satuan', 'satuans.id as satuan_id')
        // ->leftJoin('satuans', 'satuans.id', '=', 'barangs.satuan_id')
        // ->where('barangs.id', $id)
        // ->first();

        //ELOQUENT
        $persediaans = persediaan::find($id);

        return view('persediaan.show', compact('pageTitle', 'persediaans'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $pageTitle = 'Edit Persediaan';

    
        // ELOQUENT
        $satuans = Satuan::all();
        $persediaans = persediaan::find($id);
    
        return view('persediaan.edit', compact('pageTitle', 'satuans', 'persediaans'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $messages = [
            'required' => ':Attribute harus diisi.',
            'numeric' => 'Isi :attribute dengan angka',
            'KodeBarang.unique' => 'kode barang sudah ada',
        ];

        $validator = Validator::make($request->all(), [
            'KodeBarang' => 'required',
            'NamaBarang' => 'required',
            'HargaBarang' => 'required|numeric',
            'DeskripsiBarang' => 'required',
        ], $messages);


        $validator->after(function ($validator) use ($request, $id) {
            $value = $request->input('KodeBarang');
            $count = DB::table('persediaans')
                ->where('KodeBarang', $value)
                ->where('id', '<>', $id)
                ->count();

            if ($count > 0) {
                $validator->errors()->add('KodeBarang', 'Kode Barang ini sudah dipakai.');
            }
        });

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }


        // ELOQUENT
        $persediaan = persediaan::find($id);
        $persediaan ->KodeBarang = $request->KodeBarang;
        $persediaan ->NamaBarang = $request->NamaBarang;
        $persediaan ->HargaBarang = $request->HargaBarang;
        $persediaan ->DeskripsiBarang = $request->DeskripsiBarang;
        $persediaan ->satuan_id = $request->satuan;
        $persediaan ->save();

        return redirect()->route('persediaan.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {

    // ELOQUENT
    persediaan::find($id)->delete();

    return redirect()->route('persediaan.index');
    }
}
