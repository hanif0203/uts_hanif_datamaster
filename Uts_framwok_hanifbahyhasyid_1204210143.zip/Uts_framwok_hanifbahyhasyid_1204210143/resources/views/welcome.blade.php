<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TOKO SUBUR JAYA</title>
    @vite('resources/sass/app.scss')
    @vite('resources/sass/welcome.scss')
</head>
<body >
    <div class="container text-center my-5">
        <h1 class="mb-4">WELCOME TO HOME<br>TOKO SUBUR JAYA</h1>
        {{-- Contoh cara mereferensikan gambar di dalam file blade dengan menggunakan pendekatan Vite --}}
        <img class="img-thumbnail" src="{{ Vite::asset('resources/images/home.jpg') }}" alt="image" style="width: 750px;">

        <div class="col-md-2 offset-md-5 mt-4">
            <div class="d-grid gap-2">
                <a class="btn btn-dark" href="{{route('home')}}">Home</a>
            </div>
        </div>
    </div>
    @vite('resources/js/app.js')
</body>
</html>