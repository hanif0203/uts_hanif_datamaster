@extends('layouts.app')

@section('content')
    <div class="container-sm my-5">
        <div class="row justify-content-center">
            <div class="p-5 bg-light rounded-3 col-xl-4 border">
                <div class="mb-3 text-center">
                    <i class="bi-person-circle fs-1"></i>
                    <h4>Detail persediaan</h4>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="KodeBarang" class="form-label">Kode Barang</label>
                        <h5>{{ $persediaans->KodeBarang }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="NamaBarang" class="form-label">Nama Barang</label>
                        <h5>{{ $persediaans->NamaBarang }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="HargaBarang" class="form-label">Harga Barang</label>
                        <h5>{{ $persediaans->HargaBarang }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="DeskripsiBarang" class="form-label">Deskripsi Barang</label>
                        <h5>{{ $persediaans->DeskripsiBarang }}</h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="Deskripsi Barang" class="form-label">satuan</label>
                        <h5>{{ $persediaans->satuan->namasatuan }}</h5>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 d-grid">
                        <a href="{{ route('persediaan.index') }}" class="btn btn-outline-dark btn-lg mt-3"><i class="bi-arrow-left-circle me-2"></i> Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection
    @vite('resources/js/app.js')
</body>
</html>
