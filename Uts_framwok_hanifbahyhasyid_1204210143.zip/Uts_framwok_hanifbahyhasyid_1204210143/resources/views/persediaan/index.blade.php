@extends('layouts.app')

@section('content')
    <div class="container mt-4">
        <div class="row mb-0">
            <div class="col-lg-9 col-xl-10">
                <h4 class="mb-3">{{ $pageTitle }}</h4>
            </div>
            <div class="col-lg-3 col-xl-2">
                <div class="d-grid gap-2">
                    <a href="{{ route('persediaan.create') }}" class="btn btn-primary">Create persediaan</a>
                </div>
            </div>
        </div>
        <hr>
        <div class="table-responsive border p-3 rounded-3">
            <table class="table table-bordered table-hover table-striped mb-0 bg-white">
                <thead>
                    <tr>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Harga Barang</th>
                        <th>Deskripsi Barang</th>
                        <th>Satuan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>@foreach ($persediaans as $persediaan)
                    <tr>
                        <td>{{ $persediaan->KodeBarang }}</td>
                        <td>{{ $persediaan->NamaBarang }}</td>
                        <td>{{ $persediaan->HargaBarang }}</td>
                        <td>{{ $persediaan->DeskripsiBarang}}</td>
                        <td>{{ $persediaan->satuan->namasatuan }}</td>
                        <td>
                            <div class="d-flex">
                                <a href="{{ route('persediaan.show', ['persediaan' => $persediaan->id]) }}" class="btn btn-outline-dark btn-sm me-2"><i class="bi-person-lines-fill"></i></a>
                                <a href="{{ route('persediaan.edit', ['persediaan' => $persediaan->id]) }}" class="btn btn-outline-dark btn-sm me-2"><i class="bi-pencil-square"></i></a>

                                <div>
                                    <form action="{{ route('persediaan.destroy', ['persediaan' => $persediaan->id]) }}" method="POST">
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-outline-dark btn-sm me-2"><i class="bi-trash"></i></button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>


            </table>
        </div>
    </div>
@endsection
@vite('resources/js/app.js')
</body>
</html>
